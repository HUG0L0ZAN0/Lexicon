import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Slider
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {

    private lateinit var colorViewModel: ColorViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializar DataStoreManager y ViewModel
        val dataStoreManager = DataStoreManager(applicationContext)
        colorViewModel = ViewModelProvider(this, ColorViewModelFactory(dataStoreManager))
            .get(ColorViewModel::class.java)

        setContent {
            // Observa los valores de color desde el ViewModel
            val red by colorViewModel.red.collectAsState()
            val green by colorViewModel.green.collectAsState()
            val blue by colorViewModel.blue.collectAsState()

            // Crea sliders para cada color
            ColorSliders(
                red = red,
                green = green,
                blue = blue,
                onRedChange = { colorViewModel.saveColors(it, green, blue) },
                onGreenChange = { colorViewModel.saveColors(red, it, blue) },
                onBlueChange = { colorViewModel.saveColors(red, green, it) }
            )
        }
    }
}

@Composable
fun ColorSliders(
    red: Int,
    green: Int,
    blue: Int,
    onRedChange: (Int) -> Unit,
    onGreenChange: (Int) -> Unit,
    onBlueChange: (Int) -> Unit
) {
    Column {
        // Slider para el rojo
        Slider(
            value = red.toFloat(),
            onValueChange = { onRedChange(it.toInt()) },
            valueRange = 0f..255f,
            modifier = Modifier.padding(16.dp)
        )
        // Slider para el verde
        Slider(
            value = green.toFloat(),
            onValueChange = { onGreenChange(it.toInt()) },
            valueRange = 0f..255f,
            modifier = Modifier.padding(16.dp)
        )
        // Slider para el azul
        Slider(
            value = blue.toFloat(),
            onValueChange = { onBlueChange(it.toInt()) },
            valueRange = 0f..255f,
            modifier = Modifier.padding(16.dp)
        )

        // Caja que muestra el color de fondo basado en los valores RGB
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(red, green, blue))
        )
    }
}
