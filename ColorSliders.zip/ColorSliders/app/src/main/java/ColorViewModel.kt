import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ColorViewModel(private val dataStoreManager: DataStoreManager) : ViewModel() {

    private val _red = MutableStateFlow(255)
    val red: StateFlow<Int> = _red

    private val _green = MutableStateFlow(255)
    val green: StateFlow<Int> = _green

    private val _blue = MutableStateFlow(255)
    val blue: StateFlow<Int> = _blue

    init {
        loadColors()
    }

    private fun loadColors() {
        viewModelScope.launch {
            dataStoreManager.redFlow.collect { _red.value = it }
            dataStoreManager.greenFlow.collect { _green.value = it }
            dataStoreManager.blueFlow.collect { _blue.value = it }
        }
    }

    fun saveColors(red: Int, green: Int, blue: Int) {
        viewModelScope.launch {
            dataStoreManager.saveColors(red, green, blue)
        }
    }
}

class ColorViewModelFactory(private val dataStoreManager: DataStoreManager) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ColorViewModel::class.java)) {
            return ColorViewModel(dataStoreManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
