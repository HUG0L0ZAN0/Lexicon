import android.content.Context
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Extension property para crear el DataStore
val Context.dataStore by preferencesDataStore(name = "color_prefs")

class DataStoreManager(private val context: Context) {

    // Definir las claves para cada valor RGB
    private val RED_KEY = intPreferencesKey("RED")
    private val GREEN_KEY = intPreferencesKey("GREEN")
    private val BLUE_KEY = intPreferencesKey("BLUE")

    // Flujo para obtener el valor rojo
    val redFlow: Flow<Int> = context.dataStore.data
        .map { preferences ->
            preferences[RED_KEY] ?: 255 // Valor por defecto
        }

    // Flujo para obtener el valor verde
    val greenFlow: Flow<Int> = context.dataStore.data
        .map { preferences ->
            preferences[GREEN_KEY] ?: 255 // Valor por defecto
        }

    // Flujo para obtener el valor azul
    val blueFlow: Flow<Int> = context.dataStore.data
        .map { preferences ->
            preferences[BLUE_KEY] ?: 255 // Valor por defecto
        }

    // Función para guardar los valores RGB
    suspend fun saveColors(red: Int, green: Int, blue: Int) {
        context.dataStore.edit { preferences ->
            preferences[RED_KEY] = red
            preferences[GREEN_KEY] = green
            preferences[BLUE_KEY] = blue
        }
    }
}
